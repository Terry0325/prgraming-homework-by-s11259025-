#include<iostream> // Input/output stream library
#include<fstream> // File stream library
#include<cstdlib> // C standard library for utilities
using namespace std; // Standard namespace

class BoxOfProduce // Class definition for BoxOfProduce
{
public:
    void set_items_ary(string items) // Function to set items array
    {
        items_ary = items;
    }
    string get_items_ary() // Function to get items array
    {
        return(items_ary);
    }

private:
    string items_ary; // Private member variable to store items array
};

void output(BoxOfProduce items[3]); // Function prototype for output function

int main(void) // Main function
{
    string items_temp[5]; // Temporary items array
    BoxOfProduce items[3]; // Array of BoxOfProduce objects
    char change_item; // Variable to store user input for item change

    fstream items_txt("items.txt", ios::in); // Open file stream for reading
    if (items_txt.fail()) { // Check if file opening fails
        cout << "File error"; // Display error message
    }

    srand(time(0)); // Seed random number generator

    for (int i = 0; i < 5; i++) { // Loop to read items from file
        items_txt >> items_temp[i];
    }

    for (int i = 0; i < 3; i++) { // Loop to randomly assign items to BoxOfProduce objects
        int j = rand() % 5; // Generate random index
        items[i].set_items_ary(items_temp[j]); // Set item for BoxOfProduce object
    }

    output(items); // Display initial items

    do { // Loop for item change process
        cout << "\nChoose the item that you want to change (enter a number, enter 0 if you don't want to change)\n";
        cin >> change_item; // Get user input for item change
        if (change_item == '1' || change_item == '2' || change_item == '3') { // Check if input is a valid item number
            cout << "\nWhich fruit would you like to change to?\n";
            cout << "1. Broccoli\n2. Tomato\n3. Kiwi\n4. Kale\n5. Tomatillo\n";
            int item_number; // Variable to store the number of the new item
            cin >> item_number; // Get user input for new item
            items[change_item - '1'].set_items_ary(items_temp[item_number - 1]); // Set new item for selected BoxOfProduce object
        }
        else if (change_item == '0') { // Check if user wants to exit
            output(items); // Display final items
            break; // Exit loop
        }
        else { // Handle invalid input
            cout << "\nError input: " << change_item << ", please enter a number between 0 and 3\n";
        }
        output(items); // Display current items
    } while (1); // Infinite loop

    return 0; // Return 0 to indicate successful execution
}

void output(BoxOfProduce items[3]) // Function definition to display items
{
    cout << "\nThe items in the box now:\n"; // Display message
    for (int i = 0; i < 3; i++) { // Loop to display items
        cout << i + 1 << ". " << items[i].get_items_ary() << endl; // Display item number and name
    }
}
