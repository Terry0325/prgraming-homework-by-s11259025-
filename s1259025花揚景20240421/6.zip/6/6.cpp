#include<iostream>
#include<vector>
using namespace std;
int find_Max(vector<int> vgrade);

int
main(void)
{
	vector<int> vgrade;
	vector<int> value(101, 0);
	int grade;

	cout << "enter the grade one by a time(enter -1 to finish)\n";
	cin >> grade;

	do {
		if (grade != -1 && grade >= 0 && grade <= 100) {
			vgrade.push_back(grade);
		}
		else {
			cout << "\nError ipnut,please enter a interger >= 0 & <=100\n";
		}
		cin >> grade;
	} while (grade != -1);



	for (int i = 0; i < vgrade.size(); i++) { 
		
			value[vgrade[i]] += 1; 
		
	}

	for (int i = 0; i <= find_Max(vgrade); i++) { // �ק�o�̡A�ק�j�����
		
			cout << value[i] << " grade(s) of " << i << endl;
		
	}
}

int
find_Max(vector<int> vgrade)
{
	int Max = 0;
	for (int i = 0; i < vgrade.size(); i++) {
		if (vgrade[i] >= Max) {
			Max = vgrade[i];
		}
	}

	return(Max);
}