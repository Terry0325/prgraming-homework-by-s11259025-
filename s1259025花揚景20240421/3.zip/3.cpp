#include<iostream>
using namespace std;

class Weight
{
public:
	// Method to set weight in pounds
	void setWeightPounds()
	{
		cout << "\nPounds:";
		cin >> pounds;
		kilograms = pounds * 1.0 / 2.21;
		ounces = pounds * 16.0;
	}

	// Method to set weight in kilograms
	void setWeightKilograms()
	{
		cout << "\nKilograms:";
		cin >> kilograms;
		pounds = kilograms * 2.21;
		ounces = kilograms * 16.0 * 2.21;
	}

	// Method to set weight in ounces
	void setWeightOunces()
	{
		cout << "\nOunces:";
		cin >> ounces;
		pounds = ounces * (1.0 / 16.0);
		kilograms = ounces * (1.0 / 16.0) * (1.0 / 2.21);
	}

	// Method to return weight in pounds
	double returnWeightPounds()
	{
		return pounds;
	}

	// Method to return weight in kilograms
	double returnWeightKilograms()
	{
		return kilograms;
	}

	// Method to return weight in ounces
	double returnWeightOunces()
	{
		return ounces;
	}

private:
	double pounds;
	double kilograms;
	double ounces;
};

int main(void)
{
	Weight weight;
	char choice;

	cout << "\nThere are three ways to store your weight:\n1. Use pounds\n2. Use kilograms\n3. Use ounces\n";

	do {
		cout << "\nWhich one would you like to choose? (Enter 1/2/3)\n";
		cin >> choice;

		if (choice == '1') {
			weight.setWeightPounds();
			cout << "\nPounds: " << weight.returnWeightPounds();
			cout << "\nKilograms: " << weight.returnWeightKilograms();
			cout << "\nOunces: " << weight.returnWeightOunces() << "\n\n";
			break;
		}
		else if (choice == '2') {
			weight.setWeightKilograms();
			cout << "\nPounds: " << weight.returnWeightPounds();
			cout << "\nKilograms: " << weight.returnWeightKilograms();
			cout << "\nOunces: " << weight.returnWeightOunces() << "\n\n";
			break;
		}
		else if (choice == '3') {
			weight.setWeightOunces();
			cout << "\nPounds: " << weight.returnWeightPounds();
			cout << "\nKilograms: " << weight.returnWeightKilograms();
			cout << "\nOunces: " << weight.returnWeightOunces() << "\n\n";
			break;
		}
		else {
			cout << "\nError input: " << choice << "\nPlease enter number 1, 2, or 3";
		}

	} while (1);

	return 0;
}
