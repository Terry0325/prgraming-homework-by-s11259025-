#include<iostream>
using namespace std;

class Money
{
public:
	// Method to set the amount of money
	void set_money()
	{
		do {
			cout << "\nDollar:";
			cin >> dollar;
			if (dollar >= 0 && dollar <= 99) {
				break;
			}
			else {
				cout << "\nError input: " << dollar << " Please enter a number between 0 and 99";
			}
		} while (1);

		do {
			cout << "\nCent:";
			cin >> cent;
			if (cent >= 0 && cent < 100) {
				break;
			}
			else {
				cout << "\nError input: " << cent << " Please enter a number between 0 and 99";
			}
		} while (1);
	}

	// Method to return the amount of money as a double
	double return_amount() {
		return (dollar + cent * 0.01);
	}

private:
	int dollar; // Dollar amount
	int cent; // Cent amount
};

int main(void)
{
	Money money[100];
	int index = 0;
	int last_index = 0;

	cout << "Please enter at least two different Money objects (dollar & cent)\n";

	// Setting the amount for the first Money object
	money[index].set_money();
	index++;

	// Setting the amount for the second Money object
	money[index].set_money();
	last_index = index;
	index++;

	// Loop to allow user to enter more Money objects
	do {
		char y_or_n = ' ';
		cout << "\nDo you want to enter more objects? (y/n)\n";
		cin >> y_or_n;
		if (y_or_n == 'n') {
			break;
		}
		else if (y_or_n == 'y') {
			money[index].set_money();
			last_index = index;
			index++;
		}
		else {
			cout << "\nError input: " << y_or_n << " Please enter again";
		}
	} while (1);

	// Displaying the amounts of all Money objects
	for (int i = 0; i <= last_index; i++) {
		if (i == 0) {
			cout << "\n1st";
		}
		else if (i == 1) {
			cout << "\n2nd";
		}
		else if (i == 2) {
			cout << "\n3rd";
		}
		else {
			cout << "\n" << i + 1 << "th";
		}
		cout << " object: ";
		cout << money[i].return_amount();
	}

	return 0;
}
