#include<iostream>
#include<fstream>
#include<cstdlib>
using namespace std;

class Pizza
{
public:
    int type = 0; // Type of pizza (1: deep dish, 2: hand tossed, 3: pan)
    int size = 0; // Size of pizza (1: Large, 2: Medium, 3: Small)
    int num_of_pep = 0; // Number of pepperoni toppings
    int num_of_chse = 0; // Number of cheese toppings
    int per_topping = 0; // Total number of toppings
    double price = 0; // Price of the pizza

    // Method to output the description of a pizza
    void output_description(Pizza pizza[100], int i)
    {
        cout << "\nPizza " << i + 1 << ":\n" << "\n    Type: ";
        if (pizza[i].type == 1) {
            cout << "Deep Dish";
        }
        else if (pizza[i].type == 2) {
            cout << "Hand Tossed";
        }
        else if (pizza[i].type == 3) {
            cout << "Pan";
        }

        cout << "\n    Size: ";

        if (pizza[i].size == 1) {
            cout << "Large";
        }
        else if (pizza[i].size == 2) {
            cout << "Medium";
        }
        else if (pizza[i].size == 3) {
            cout << "Small";
        }

        cout << "\n    Toppings: Cheese + " << pizza[i].num_of_chse << ", Pepperoni + " << pizza[i].num_of_pep;
        cout << "\n    Price = " << compute_price(pizza, i);
        i += 1;
    }

    // Method to compute the price of a pizza
    double compute_price(Pizza pizza[100], int i)
    {
        if (pizza[i].type == 1) {
            return(17 + pizza[i].per_topping * 2);
        }
        else if (pizza[i].type == 2) {
            return(14 + pizza[i].per_topping * 2);
        }
        else if (pizza[i].type == 3) {
            return(10 + pizza[i].per_topping * 2);
        }
    }
};

int main(void)
{
    Pizza pizza[100]; // Array to store pizza objects
    char topping_add[100]; // Array to store user input for adding toppings
    char keep_order[100]; // Array to store user input for continuing or ending order
    int i = 0; // Index for iterating through pizzas
    int finish = 0; // Flag to indicate if order is finished

    do {
        cout << "\nWhich type of pizza do you want\n1. Deep Dish\n2. Hand Tossed\n3. Pan\n(hint: please enter the number)\n\ntype:";
        cin >> pizza[i].type;
        cout << "\nWhich size of pizza do you want\n1. Large\n2. Medium\n3. Small\n(hint: please enter the number)\n\nsize:";
        cin >> pizza[i].size;

        do {
            cout << "\nDo you want to add some cheese or pepperoni? (enter y/n)\n";
            cin >> topping_add[i];
            if (topping_add[i] == 'n') {
                break;
            }
            else if (topping_add[i] == 'y') {
                cout << "cheese:";
                cin >> pizza[i].num_of_chse;
                cout << "pepperoni:";
                cin >> pizza[i].num_of_pep;
                break;
            }
            else {
                cout << "\n\nError input:" << topping_add[i] << "\nPlease enter again\n";
            }
        } while (1);

        pizza[i].per_topping = pizza[i].num_of_pep + pizza[i].num_of_chse;
        pizza[i].output_description(pizza, i);

        do {
            cout << "\n\nAny other pizza that you want to order? (enter y/n)\n";
            cin >> keep_order[i];
            if (keep_order[i] == 'n') {
                finish = 1;
                break;
            }
            else if (keep_order[i] == 'y') {
                i += 1;
                break;
            }
            else {
                cout << "\n\nError input:" << keep_order[i] << "\nPlease enter again\n";
            }
        } while (1);
    } while (!finish);
}
