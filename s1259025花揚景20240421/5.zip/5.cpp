#include<iostream> // Input/output stream library
using namespace std; // Standard namespace

class HotDogStand // Class definition for HotDogStand
{
private:
    int ID; // Private member variable for ID
    int sold; // Private member variable for number of hotdogs sold
    static int all_hotdog; // Static member variable to keep track of total hotdogs sold across all stands

public:
    HotDogStand(int id, int hotdog) // Constructor to initialize ID and number of hotdogs sold
    {
        ID = id;
        sold = hotdog;
        all_hotdog += sold; // Increment total hotdogs sold
    }

    void JustSold() // Function to simulate selling one hotdog
    {
        sold++; // Increment number of hotdogs sold by this stand
        all_hotdog++; // Increment total hotdogs sold
    }

    int get_sold() // Function to get number of hotdogs sold by this stand
    {
        return(sold);
    }

    static int get_all_hotdog() // Static function to get total hotdogs sold across all stands
    {
        return(all_hotdog);
    }

};

int HotDogStand::all_hotdog = 0; // Initializing static member variable

int main(void) // Main function
{
    HotDogStand HotDogStand1(1, 10); // Creating instance of HotDogStand with ID 1 and 10 hotdogs sold
    HotDogStand HotDogStand2(2, 15); // Creating instance of HotDogStand with ID 2 and 15 hotdogs sold
    HotDogStand HotDogStand3(3, 20); // Creating instance of HotDogStand with ID 3 and 20 hotdogs sold

    HotDogStand2.JustSold(); // Simulating selling one hotdog from HotDogStand2

    cout << HotDogStand1.get_sold(); // Displaying number of hotdogs sold by HotDogStand1
    cout << HotDogStand2.get_sold(); // Displaying number of hotdogs sold by HotDogStand2
    cout << HotDogStand3.get_sold(); // Displaying number of hotdogs sold by HotDogStand3

    cout << HotDogStand::get_all_hotdog(); // Displaying total number of hotdogs sold across all stands

    return 0; // Returning 0 to indicate successful execution
}
